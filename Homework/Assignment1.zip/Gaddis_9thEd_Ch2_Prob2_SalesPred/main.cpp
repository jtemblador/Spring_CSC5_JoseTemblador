/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    
    float  sales=8600000;
    
    cout<<"East Coast Sales Division generates $"<<sales*0.58<<" in revenue"
        " if this year they generate $"<<sales<<" in sales.\n";
    
    
    //Exit the Program - Cleanup
    return 0;
}