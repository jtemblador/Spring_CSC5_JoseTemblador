/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  C++ Template
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants only
//Math, Physics, Conversions, Higher Order Dimension 

//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed
    char    p1, p2;
    //Declare all variables
    
    //Initialize Variables
    cout<<"Rock Paper Scissors Game\n";
    cout<<"Input Player 1 and Player 2 Choices\n";
    
    cin>>p1>>p2;
    
    
         if ((p1=='R')&&(p2=='S'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='R')&&(p2=='s'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='r')&&(p2=='S'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='r')&&(p2=='s'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='S')&&(p2=='R'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='S')&&(p2=='r'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='s')&&(p2=='R'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='s')&&(p2=='a'))
            cout<<"Rock breaks scissors.";
    
    else if ((p1=='P')&&(p2=='R'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='P')&&(p2=='r'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='p')&&(p2=='R'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='p')&&(p2=='r'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='R')&&(p2=='P'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='R')&&(p2=='p'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='r')&&(p2=='P'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='r')&&(p2=='p'))
            cout<<"Paper covers rock.";
    
    else if ((p1=='S')&&(p2=='P'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='S')&&(p2=='p'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='s')&&(p2=='P'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='S')&&(p2=='p'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='P')&&(p2=='S'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='P')&&(p2=='s'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='p')&&(p2=='S'))
            cout<<"Scissors cuts paper.";
    
    else if ((p1=='p')&&(p2=='s'))
            cout<<"Scissors cuts paper.";
    
    else 
        
    
    return 0;
}