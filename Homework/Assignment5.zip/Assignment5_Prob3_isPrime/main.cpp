/* 
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
bool isPrime(int); //Determine if the input number is prime.

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int a;
    //Initialize Variables
    cout<<"Input a number to test if Prime.\n";
    cin>>a;
    //Process/Map inputs to outputs
    
    //Output data
    if (isPrime(a)) cout<<a<<" is not prime.";
    else cout<<a<<" is prime.";
    //Exit stage right!
    return 0;
}

bool isPrime(int a) {
    if (a%2==0) return true;
    else return false;
}